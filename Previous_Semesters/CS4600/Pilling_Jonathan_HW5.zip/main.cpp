#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <fstream>
#include <vector>
#include <iostream>
#include <cassert>
#include <random>
#include <algorithm>
#include <Eigen>

using namespace Eigen;

// image background color
Vector3f bgcolor(1.0f, 1.0f, 1.0f);

/*More Colors*/
Vector3f red(255.0f, 0, 0);

// lights in the scene
std::vector<Vector3f> lightPositions = { Vector3f(  0.0, 60, 60)
                                       , Vector3f(-60.0, 60, 60)
                                       , Vector3f( 60.0, 60, 60) };

class Sphere
{
public:
	Vector3f center;  // position of the sphere
	float radius;  // sphere radius
	Vector3f surfaceColor; // surface color
	
  Sphere(
		const Vector3f &c,
		const float &r,
		const Vector3f &sc) :
		center(c), radius(r), surfaceColor(sc)
	{
	}

    // line vs. sphere intersection (note: this is slightly different from ray vs. sphere intersection!)
	bool intersect(const Vector3f &rayOrigin, const Vector3f &rayDirection, float &t0, float &t1) const
	{
		Vector3f l = center - rayOrigin;
		float tca = l.dot(rayDirection);
		if (tca < 0) return false;
		float d2 = l.dot(l) - tca * tca;
		if (d2 > (radius * radius)) return false;
        float thc = sqrt(radius * radius - d2);
		t0 = tca - thc;
		t1 = tca + thc;

		return true;
	}
};

// diffuse reflection model
Vector3f diffuse(const Vector3f &L, // direction vector from the point on the surface towards a light source
	const Vector3f &N, // normal at this point on the surface
	const Vector3f &diffuseColor,
	const float kd // diffuse reflection constant
	)
{
	Vector3f resColor = Vector3f::Zero();

	// TODO: implement diffuse shading model
	resColor = 0.333 * kd * diffuseColor * std::max(L.dot(N), 0.f);

	return resColor;
}

// Phong reflection model
Vector3f phong(const Vector3f &L, // direction vector from the point on the surface towards a light source
               const Vector3f &N, // normal at this point on the surface
               const Vector3f &V, // direction pointing towards the viewer
               const Vector3f &diffuseColor, 
               const Vector3f &specularColor, 
               const float kd, // diffuse reflection constant
               const float ks, // specular reflection constant
               const float alpha) // shininess constant
{
	Vector3f resColor = Vector3f::Zero();

	Vector3f R = 2 * N * N.dot(L) - L;

	// TODO: implement Phong shading model

	resColor = diffuse(L, N, diffuseColor, kd) + ( 0.333 * specularColor * ks * pow(std::max(R.dot(V), 0.f), alpha));

	return resColor;
}

Vector3f trace(
	const Vector3f &rayOrigin,
	const Vector3f &rayDirection,
	const std::vector<Sphere> &spheres)
{
	Vector3f A = Vector3f::Zero();
	Vector3f R = Vector3f::Zero();

	Vector3f pixelColor = bgcolor;
	Vector3f diffuseStart = Vector3f::Zero();
	Vector3f colorStart = Vector3f::Zero();
	// TODO: implement ray tracing as described in the homework description
	Vector3f Light;

	float t0 = 0;
	float t1 = 0;

	float jt0 = 0;
	float jt1 = 1; 

	float ii0 = 0;
	float ii1 = 0;

	float oc0 = 0;
	float oc1 = 0;

	float lowestt0 = 100000000;
	float highestii0 = 0;

	float shadowCount = 0;

	//Looping through all the spheres
	for (int i = 0; i < spheres.size(); i++)
	{
		if (spheres[i].intersect(rayOrigin, rayDirection, t0, t1)) //Tracks the lowest t0 value, makes sure to set color to sphere with smallest t0 value.
		{
			if (t0 < lowestt0)
			{
				lowestt0 = t0;

				A = (rayOrigin + (t0 * rayDirection)); //Point where the ray hits the sphere 

				diffuseStart = Vector3f::Zero(); //If we have entered this section, we need brand new color information
				colorStart = Vector3f::Zero();

				for (int j = 0; j < lightPositions.size(); j++)
				{
					Light = lightPositions[j] - A;
					Light.normalize();

					if (spheres[i].intersect(A, Light, jt0, jt1)) //This will set shadows for individual spheres
					{
						//shadowCount++;
					}
					// Else: We're casting a shadow

					//Check for occluding spheres
					for (int ii = 0; ii < spheres.size(); ii++)
					{					
						bool Occlusion = spheres[ii].intersect(A, Light, ii0, ii1);
						if (ii == i) //This stops spheres from occluding with themselves
						{
							//Do nothing
						}
						else if (Occlusion)
						{
							shadowCount++;
						}
					}


					if (shadowCount == 0)
					{
						//diffuseStart = diffuseStart + (spheres[i].surfaceColor * 0.333);
						Vector3f Normal = A - spheres[i].center;
						Normal.normalize();

						//diffuseStart = diffuseStart +  diffuse(Light, Normal, spheres[i].surfaceColor, 1);

						Vector3f V = rayDirection * (-1);

						Vector3f PhongRay = Vector3f::Ones();

						diffuseStart = diffuseStart + phong(Light, Normal, V, spheres[i].surfaceColor, PhongRay, 1, 3, 100);
					}
				}

				/*FOR TASKS 1 & 2*/
				//diffuseStart = spheres[i].surfaceColor * (1 - (0.333 * shadowCount));

				/*Normalizing vector for sphere*/
				//Vector3f Normal = A - spheres[i].center;
				//Normal.normalize();

				

				/*For diffusing illumination*/
				pixelColor = diffuseStart;

				/*For Phong illumination*/

				//pixelColor = phong(Light, Normal, V, diffuseStart, PhongRay, 1, 3, 100);

				shadowCount = 0; //Reset this value
			}			
		}
	}

	return pixelColor;
}

void render(const std::vector<Sphere> &spheres)
{
  unsigned width = 640;
  unsigned height = 480;
  Vector3f *image = new Vector3f[width * height];
  Vector3f *pixel = image;
  float invWidth  = 1 / float(width);
  float invHeight = 1 / float(height);
  float fov = 30;
  float aspectratio = width / float(height);
	float angle = tan(M_PI * 0.5f * fov / 180.f);
	
	// Trace rays
	for (unsigned y = 0; y < height; ++y) 
	{
		for (unsigned x = 0; x < width; ++x) 
		{
			float rayX = (2 * ((x + 0.5f) * invWidth) - 1) * angle * aspectratio;
			float rayY = (1 - 2 * ((y + 0.5f) * invHeight)) * angle;
			Vector3f rayDirection(rayX, rayY, -1);
			rayDirection.normalize();
			*(pixel++) = trace(Vector3f::Zero(), rayDirection, spheres);
		}
	}
	
	// Save result to a PPM image
	std::ofstream ofs("./render.ppm", std::ios::out | std::ios::binary);
	ofs << "P6\n" << width << " " << height << "\n255\n";
	for (unsigned i = 0; i < width * height; ++i) 
	{
		const float x = image[i](0);
		const float y = image[i](1);
		const float z = image[i](2);

		ofs << (unsigned char)(std::min(float(1), x) * 255) 
			  << (unsigned char)(std::min(float(1), y) * 255) 
			  << (unsigned char)(std::min(float(1), z) * 255);
	}
	
	ofs.close();
	delete[] image;
}

int main(int argc, char **argv)
{
	std::vector<Sphere> spheres;
	// position, radius, surface color
	spheres.push_back(Sphere(Vector3f(0.0, -10004, -20), 10000, Vector3f(0.50, 0.50, 0.50)));
	spheres.push_back(Sphere(Vector3f(0.0, 0, -20), 4, Vector3f(1.00, 0.32, 0.36)));
	spheres.push_back(Sphere(Vector3f(5.0, -1, -15), 2, Vector3f(0.90, 0.76, 0.46)));
	spheres.push_back(Sphere(Vector3f(5.0, 0, -25), 3, Vector3f(0.65, 0.77, 0.97)));
	spheres.push_back(Sphere(Vector3f(-5.5, 0, -13), 3, Vector3f(0.90, 0.90, 0.90)));

	render(spheres);

	return 0;
}
